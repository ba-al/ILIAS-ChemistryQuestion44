<?php
 
// alphanumerical ID of the plugin; never change this
$id = "assJSMEQuestion";
 
// code version; must be changed for all code changes
$version = "1.1.0";
 
// ilias min and max version; must always reflect the versions that should
// run with the plugin
$ilias_min_version = "4.4.0";
$ilias_max_version = "4.4.999";

// add the responsible person for the plugin
$responsible = "Yves Annanias";
$responsible_mail = "yves.annanias@llz.uni-halle.de";
//  Dr. Peter Ertl: 
//  http://peter-ertl.com/ 
//  http://peter-ertl.com/jsme/index.html
?>
